module com.example.kyrsovaya {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires itextpdf;
    requires java.desktop;


    opens com.example.kyrsovaya to javafx.fxml;
    exports com.example.kyrsovaya;
}