package com.example.kyrsovaya;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    @FXML
    private GridPane gridPane;
    @FXML
    private ComboBox filter;
    @FXML
    private ComboBox sortirovca;
    @FXML
    private ScrollPane scrol;

    @FXML
    private Button avtorization;
    DB db = new DB();

    int colum = 0;
    int root = 0;
    int count = 0;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        sortirovca.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        filter.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        avtorization.setStyle("-fx-background-color: #f39870");
        gridPane.setHgap(20);
        gridPane.setVgap(20);

        ArrayList<String> tovar = null;


        try {
            tovar = db.getTovar();
            create(tovar);



        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        try {
            ArrayList<String> tovarType= db.getTovarType();
            tovarType.add("Все");
            filter.getItems().addAll(tovarType);
            sortirovca.getItems().addAll("Название от А-Я", "Название от Я-А", "По цене (от большей)", "По цене (от меньшей)");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
    public void clickFilter(ActionEvent event) throws SQLException, ClassNotFoundException {

        gridPane.getChildren().clear();

        gridPane.setHgap(20);
        gridPane.setVgap(20);

        colum = 0;
        root = 0;
        count = 0;



        String tovarType = (String) filter.getValue();

        if(tovarType.equals("Все")){
            ArrayList<String> tovar = db.getTovar();
            create(tovar);
        }else{
            ArrayList<String> tovar = db.getFilter(tovarType);
            create(tovar);
        }





    }

    public void clickSortirovca(ActionEvent event) throws SQLException, ClassNotFoundException {

        gridPane.getChildren().clear();

        gridPane.setHgap(20);
        gridPane.setVgap(20);

        String name = "name";
        String cost = "cost";

        colum = 0;
        root = 0;
        count = 0;


        String tovarType = (String) sortirovca.getValue();



        if(tovarType.equals("Название от А-Я")){
            ArrayList<String> tovar = db.getSortirovcaAZ(name);
            create(tovar);
        }else if (tovarType.equals("Название от Я-А")){
            ArrayList<String> tovar = db.getSortirovcaZA(name);
            create(tovar);
        }else if (tovarType.equals("По цене (от большей)")){
            ArrayList<String> tovar = db.getSortirovcaZA(cost);
            create(tovar);
        }else if (tovarType.equals("По цене (от меньшей)")){
            ArrayList<String> tovar = db.getSortirovcaAZ(cost);
            create(tovar);
        }

    }

    public void create(ArrayList<String> tovar){
        for(int i = 0; i < tovar.size(); i++){
            VBox vBox = new VBox();
            File file = new File("src/"+tovar.get(i));
            String localUrl = file.toURI().toString();
            ImageView image = new ImageView(localUrl);

            image.setFitHeight(200);
            image.setFitWidth(200);
            vBox.getChildren().add(image);
            vBox.setStyle("-fx-border-style: solid;" + "-fx-border-width: 1;" + "-fx-border-color: #f39870");

            Label title = new Label();
            Label razmer = new Label();
            Label cost = new Label();
            title.setText(tovar.get(++i));
            title.setMaxWidth(150);
            title.setMinHeight(40);
            title.setAlignment(Pos.CENTER);
            title.setFont(new Font("Italic", 15));
            title.setTextFill(Color.web("#040f2c"));
            razmer.setText("Площадь: "+tovar.get(++i));
            razmer.setMaxWidth(300);
            razmer.setMinHeight(40);
            cost.setText("Стоимость: "+tovar.get(++i));
            cost.setMaxWidth(300);
            cost.setMinHeight(40);
            cost.setFont(new Font("Italic", 20));
            cost.setTextFill(Color.web("#FC2323"));
            vBox.getChildren().add(title);
            vBox.getChildren().add(razmer);
            vBox.getChildren().add(cost);

            vBox.setAlignment(Pos.CENTER);
            gridPane.setHalignment(vBox, HPos.CENTER);
            gridPane.add(vBox, colum, root);

            if (count % 2 == 0){
                colum++;
                count++;
            }else{
                root++;
                colum--;
                count++;
            }

        }
    }
    //переход на страницу регистрации
    public void onRegistration() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("avtorization.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 866, 551);
        stage.getIcons().add(new Image("file:src/img/home.jpeg"));
        stage.setTitle("Авторизация!");
        stage.setScene(scene);
        stage.show();
        Stage stageNow = (Stage) avtorization.getScene().getWindow();
        stageNow.close();

    }
}