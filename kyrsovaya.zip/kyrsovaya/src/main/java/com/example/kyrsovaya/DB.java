package com.example.kyrsovaya;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

public class DB {
    private final String HOST = "localhost";
    private final String PORT = "3306";
    private final String DB_NAME = "user35";


    private Connection dbConn = null;

    //подключение к базе данных
    private Connection getDbConnection() throws ClassNotFoundException, SQLException {
        Properties properties = new Properties();

        properties.setProperty("user", "root");
        properties.setProperty("password", "root");
        properties.setProperty("useUnicode", "true");
        properties.setProperty("characterEncoding", "utf8");

        String connStr = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB_NAME;
        Class.forName("com.mysql.cj.jdbc.Driver");


        dbConn = DriverManager.getConnection(connStr, properties);


        return dbConn;
    }

    //вывод информации о товаре
    public ArrayList<String> getTovar() throws SQLException, ClassNotFoundException {
        String zapros = "select img, name, razmer, cost from Gilya";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        ArrayList<String> result = new ArrayList<>();
        while (resultSet.next()){
            result.add(resultSet.getString(1));
            result.add(resultSet.getString(2));
            result.add(resultSet.getString(3));
            result.add(resultSet.getString(4));

        }
        statement.close();
        return result;

    }

    //выводим объявления при использовании фильтра
    public ArrayList<String> getFilter(String name) throws SQLException, ClassNotFoundException {
        String zapros = "select img, Gilya.name, razmer, cost from Gilya, Type where Gilya.type=Type.id and Type.name='"+name+"'";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        ArrayList<String> result = new ArrayList<>();
        while (resultSet.next()){
            result.add(resultSet.getString(1));
            result.add(resultSet.getString(2));
            result.add(resultSet.getString(3));
            result.add(resultSet.getString(4));

        }
        statement.close();
        return result;



    }

    //вывод типов жилья
    public ArrayList<String> getTovarType() throws SQLException, ClassNotFoundException {
        String zapros = "SELECT name FROM Type";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        ArrayList<String> result = new ArrayList<>();
        while (resultSet.next()) {
            result.add(resultSet.getString(1));

        }
        statement.close();
        return result;
    }

    //выводим объявления при использовании сортировки по возрастания
    public ArrayList<String> getSortirovcaZA(String name) throws SQLException, ClassNotFoundException {
        String zapros = "select img, name, razmer, cost from Gilya ORDER BY "+name+" DESC";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        ArrayList<String> result = new ArrayList<>();
        while (resultSet.next()){
            result.add(resultSet.getString(1));
            result.add(resultSet.getString(2));
            result.add(resultSet.getString(3));
            result.add(resultSet.getString(4));

        }
        statement.close();
        return result;

    }
    //выводим объявления при использовании сортировки по убыванию
    public ArrayList<String> getSortirovcaAZ(String name) throws SQLException, ClassNotFoundException {
        String zapros = "select img, name, razmer, cost from Gilya ORDER BY "+name+" ";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        ArrayList<String> result = new ArrayList<>();
        while (resultSet.next()){
            result.add(resultSet.getString(1));
            result.add(resultSet.getString(2));
            result.add(resultSet.getString(3));
            result.add(resultSet.getString(4));

        }
        statement.close();
        return result;
    }
    //если ли пользоваль в базе данных
    public int[] getRegistration(String login, String password) throws SQLException, ClassNotFoundException {
        String zapros = "SELECT count(*), dolgnost FROM Sotrydnic where login = '"+login+"' and password='"+password+"'";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        int[] result = new int[2];

        while (resultSet.next()){
            result[0] = resultSet.getInt(1);
            result[1] = resultSet.getInt(2);

        }
        statement.close();
        return result;
    }
    //вывод объявлений со статусами
    public ArrayList<String> getStatys() throws SQLException, ClassNotFoundException {
        String zapros = "SELECT img, Gilya.name, razmer, cost, Statys.name, Gilya.id FROM Gilya, Statys where Statys.id=Gilya.statys";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        ArrayList<String> result = new ArrayList<>();
        while (resultSet.next()){
            result.add(resultSet.getString(1));
            result.add(resultSet.getString(2));
            result.add(resultSet.getString(3));
            result.add(resultSet.getString(4));
            result.add(resultSet.getString(5));
            result.add(resultSet.getString(6));

        }
        statement.close();
        return result;
    }

    //обновление статуса объявления
    public void getUpdate(String id, String statys) throws SQLException, ClassNotFoundException {
        int idStatys = 0;
        if (statys.equals("Продается")){
            idStatys = 1;
        }else if (statys.equals("Подписывается договор")){
             idStatys = 2;
        }else if (statys.equals("Сдается в аренду")){
             idStatys = 3;
        }else if (statys.equals("Продано")){
             idStatys = 4;
        }
        String sql1 = "UPDATE gilya SET statys = '"+idStatys+"' WHERE id = '"+id+"'";
        Statement statement = getDbConnection().createStatement();
        statement.executeUpdate(sql1);


    }

    //обновление объявлений
    public void getUpdateAdministrator(String name, String text, String id) throws SQLException, ClassNotFoundException {
                String sqlname = null;
                if(name.equals("Название")){
                    sqlname="name";
                }else if(name.equals("Адрес")){
                    sqlname="adres";
                }else if(name.equals("Размер")){
                    sqlname="razmer";
                }else if(name.equals("Стоимость")){
                    sqlname="cost";
                }else if(name.equals("Дополнительная информация")){
                    sqlname="dopinformation";
                }else if(name.equals("Имя продавца")){
                    sqlname="nameProdavez";
                }
        String sql1 = "UPDATE gilya SET "+sqlname+" = '"+text+"' WHERE id = '"+id+"'";
        Statement statement = getDbConnection().createStatement();
        statement.executeUpdate(sql1);


    }



    //добавление объявлений
    public void getInsert(Integer id, String name, String address, String razmer, String cost, String dop, String prodavez, String dataS, String dataE, String type, Integer statys, Integer sotrydnic, String img) throws SQLException, ClassNotFoundException {
        int typeId = 0;
        if (type.equals("1-компатная квартира")){
            typeId = 1;
        }else if (type.equals("2-комнатная квартира")){
            typeId = 2;
        }else if (type.equals("3-комнатная квартира")){
            typeId = 3;
        }else if (type.equals("Сутдия")){
            typeId = 4;
        }else if (type.equals("Частный дом")){
            typeId = 5;
        }
        String sql1 = "INSERT INTO `user35`.`gilya` (`id`, `name`, `adres`, `razmer`, `cost`, `dopinformation`, `nameProdavez`, `dataSozdaniya`, `dataEnd`, `type`, `statys`, `sotrydnic`, `img`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement pst;
        pst = dbConn.prepareStatement(sql1);
        pst.setInt(1, id);
        pst.setString(2, name);
        pst.setString(3, address);
        pst.setString(4, razmer);
        pst.setString(5, cost);
        pst.setString(6, dop);
        pst.setString(7, prodavez);
        pst.setString(8,  dataS);
        pst.setString(9,  dataE);
        pst.setInt(10, typeId);
        pst.setInt(11, statys);
        pst.setInt(12, sotrydnic);
        pst.setString(13, img);
        pst.executeUpdate();

    }
    //вывод максимального id жилья
    public Integer getId() throws SQLException, ClassNotFoundException {
        String zapros = "select max(id) from gilya";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        int result = 0;

        while (resultSet.next()){
            result = resultSet.getInt(1);
        }
        statement.close();
        return result;
    }
    //поиск пользователя в базе данных
    public int[] getRegistrationPolzovatel(String login, String password) throws SQLException, ClassNotFoundException {
        String zapros = "SELECT count(*), id FROM polzovateli where login = '"+login+"' and password='"+password+"'";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        int result[] = new int[2];
        while (resultSet.next()){
            result[0] = resultSet.getInt(1);
            result[1] = resultSet.getInt(2);
        }
        statement.close();
        return result;
    }

    //добавление объявления в избранное
    public void getLike(String id, String idGelya) throws SQLException {
        String zapros = "INSERT INTO `user35`.`polzovateli_has_gilya` (`Polzovateli_id`, `Gilya_id`) VALUES (?, ?)";
        PreparedStatement pst;
        pst = dbConn.prepareStatement(zapros);
        pst.setString(1, id);
        pst.setString(2, idGelya);
        pst.executeUpdate();
    }

    //вывод жилья для пользователя
    public ArrayList<String> getGilyaPolzovatel() throws SQLException, ClassNotFoundException {
        String zapros = "SELECT img, Gilya.name, razmer, cost, Gilya.id FROM Gilya";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        ArrayList<String> result = new ArrayList<>();
        while (resultSet.next()){
            result.add(resultSet.getString(1));
            result.add(resultSet.getString(2));
            result.add(resultSet.getString(3));
            result.add(resultSet.getString(4));
            result.add(resultSet.getString(5));


        }
        statement.close();
        return result;
    }

    //вывод объявления в избранном
    public ArrayList<String> getLikeGilya(String idPolzovatel) throws SQLException, ClassNotFoundException {
        String zapros = "SELECT img, Gilya.name, razmer, cost FROM user35.polzovateli_has_gilya, gilya where Polzovateli_id='"+idPolzovatel+"' and polzovateli_has_gilya.Gilya_id=gilya.id";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        ArrayList<String> result = new ArrayList<>();
        while (resultSet.next()){
            result.add(resultSet.getString(1));
            result.add(resultSet.getString(2));
            result.add(resultSet.getString(3));
            result.add(resultSet.getString(4));



        }
        statement.close();
        return result;
    }
    //удаление объявления
    public void getDelete(String id) throws SQLException, ClassNotFoundException {
        String sql1 = "DELETE FROM `gilya` WHERE (`id` = '"+id+"')";
        Statement statement = getDbConnection().createStatement();
        statement.executeUpdate(sql1);
    }

    //вывод информации для отчета
    public ArrayList<String> getOthet() throws SQLException, ClassNotFoundException {
        java.lang.String zapros = " SELECT name, adres, cost, dopinformation, nameProdavez, dataSozdaniya, sot.FIO FROM user35.gilya, sotrydnic as sot where sot.id=gilya.sotrydnic and statys=1";
        Statement statement = getDbConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(zapros);
        ArrayList<java.lang.String> result = new ArrayList<>();
        while (resultSet.next()){
            result.add(resultSet.getString(1));
            result.add(resultSet.getString(2));
            result.add(resultSet.getString(3));
            result.add(resultSet.getString(4));
            result.add(resultSet.getString(5));
            result.add(resultSet.getString(6));
            result.add(resultSet.getString(7));

        }
        statement.close();
        return result;
    }

}
