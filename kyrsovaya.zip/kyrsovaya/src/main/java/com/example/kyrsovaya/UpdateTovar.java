package com.example.kyrsovaya;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class UpdateTovar implements Initializable {

    @FXML
    ComboBox wathUpdate;
    @FXML
    TextArea textUpdate;
    @FXML
    Button update;

    DB db = new DB();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //добавляем стили для элементов окна
        wathUpdate.getItems().addAll("Название", "Адрес", "Размер", "Стоимость", "Дополнительная информация", "Имя продавца");
        wathUpdate.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        textUpdate.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        update.setStyle("-fx-background-color: #f39870");

    }

    public void onUpdate(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        //берем id объявления
        String idTovar = Administrator.id;
        //вызываме запрос на обновление
        db.getUpdateAdministrator((String) wathUpdate.getValue(), textUpdate.getText(), idTovar);
    }
}
