package com.example.kyrsovaya;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Avtorization implements Initializable {
    DB db = new DB();


    @FXML
    public Button vxod;
    @FXML
    public TextField login;
    @FXML
    public TextField password;

    @FXML
    public PasswordField passwordField;

    @FXML
    public Label error;

    @FXML
    public CheckBox openPassword;
    public static int id  = 0;
    public static int idPolzovatel  = 0;


    public void onVxod() throws SQLException, ClassNotFoundException, IOException {



        //задаем строки со значениями введенных данных
        String passwordText = password.getText();
        String passwordFieldText = passwordField.getText();
        String loginText = login.getText();

        //массив с полученныем результатом из таблицы
        int[] registration = db.getRegistration(loginText, passwordText);
        int[] registration1 = db.getRegistration(loginText, passwordFieldText);

        int registration2[] = db.getRegistrationPolzovatel(loginText, passwordText);
        int registration3[] = db.getRegistrationPolzovatel(loginText, passwordFieldText);

        //если такой пользователь есть в базе данных то мы берем его должность
        if (registration[0] == 1 || registration1[0] == 1){

            if (registration[0] == 1){
                id = registration[1];
            }else {
                id = registration1[1];
            }

            //если должность директор переход в личный кабинет директора
            Stage stage = new Stage();
            if (id == 1){
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("administrator.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 866, 551);
                stage.setTitle("Диретор");
                stage.getIcons().add(new Image("file:src/img/home.jpeg"));
                stage.setScene(scene);
                stage.show();
                Stage stageNow = (Stage) vxod.getScene().getWindow();
                stageNow.close();

            //есди должность риэлтор, то переход в дичный кабинет риэлтора
            }else if (id == 2){
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("panel.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 866, 551);
                stage.getIcons().add(new Image("file:src/img/home.jpeg"));
                stage.setTitle("Риэлтор");
                stage.setScene(scene);
                stage.show();
                Stage stageNow = (Stage) vxod.getScene().getWindow();
                stageNow.close();


            }

            //если в систему заходит пользоаптель, то переход в личный кабинет пользователя
        }else if(registration2[0] == 1 || registration3[0] == 1){
            if (registration2[0] == 1){
                 idPolzovatel = registration2[1];
            }else {
                 idPolzovatel = registration3[1];
            }
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("polzovatel.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 866, 551);
            stage.getIcons().add(new Image("file:src/img/home.jpeg"));
            stage.setTitle("Пользователь");
            stage.setScene(scene);
            stage.show();
            Stage stageNow = (Stage) vxod.getScene().getWindow();
            stageNow.close();

            //если такого пользователя или работника нет, то выводится ошибка
        }else {
            error.setText("Веден неверный логин или пароль");
        }

    }

    //показать пароль
    public void onCheak(){
        if(openPassword.isSelected()){
            String passwordText = passwordField.getText();
            passwordField.setVisible(false);
            password.setText(passwordText);
        }else{
            String passwordText = password.getText();
            passwordField.setVisible(true);
            passwordField.setText(passwordText);
        }
    }

    //задаем стили при запуске окна
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        login.setStyle("-fx-border-style: solid;" + "-fx-border-width: 1;" + "-fx-border-color: #f39870");
        password.setStyle("-fx-border-style: solid;" + "-fx-border-width: 1;" + "-fx-border-color: #f39870");
        passwordField.setStyle("-fx-border-style: solid;" + "-fx-border-width: 1;" + "-fx-border-color: #f39870");
        vxod.setStyle("-fx-background-color: #f39870");
    }
}
