package com.example.kyrsovaya;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Panel implements Initializable{
    @FXML
    private GridPane gridPane;
    @FXML
    private ComboBox filter;
    @FXML
    private ComboBox sortirovca;
    @FXML
    private Button exit;
    @FXML
    private Button news;

    private static  HelloController hc = new HelloController();
    private VBox vBox1 = new VBox();
    DB db = new DB();


    int colum = 0;
    int root = 0;
    int count = 0;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        sortirovca.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        filter.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        exit.setStyle("-fx-background-color: #f39870");
        news.setStyle("-fx-background-color: #f39870");
        gridPane.getChildren().clear();

        gridPane.setHgap(10);
        gridPane.setVgap(10);


        ArrayList<String> tovar = null;

        try {
            tovar = db.getStatys();
            System.out.println(tovar);
            createPanel(tovar);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        try {
            ArrayList<String> tovarType= db.getTovarType();
            tovarType.add("Все");
            filter.getItems().addAll(tovarType);
            sortirovca.getItems().addAll("Название от А-Я", "Название от Я-А", "По цене (от большей)", "По цене (от меньшей)");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
    public void clickFilter1(ActionEvent event) throws SQLException, ClassNotFoundException {


        gridPane.getChildren().clear();

        gridPane.setHgap(10);
        gridPane.setVgap(10);

        colum = 0;
        root = 0;

        String tovarType = (String) filter.getValue();

        if(tovarType.equals("Все")){
            ArrayList<String> tovar = db.getStatys();
            createPanel(tovar);
        }else{
            ArrayList<String> tovar = db.getFilter(tovarType);
            createPanel(tovar);
        }

    }

    public void clickSortirovca1(ActionEvent event) throws SQLException, ClassNotFoundException {

        gridPane.getChildren().clear();

        String name = "name";
        String cost = "cost";

        colum = 0;
        root = 0;


        String tovarType = (String) sortirovca.getValue();



        if(tovarType.equals("Название от А-Я")){
            ArrayList<String> tovar = db.getSortirovcaAZ(name);
            createPanel(tovar);
        }else if (tovarType.equals("Название от Я-А")){
            ArrayList<String> tovar = db.getSortirovcaZA(name);
            createPanel(tovar);
        }else if (tovarType.equals("По цене (от большей)")){
            ArrayList<String> tovar = db.getSortirovcaZA(cost);
            createPanel(tovar);
        }else if (tovarType.equals("По цене (от меньшей)")){
            ArrayList<String> tovar = db.getSortirovcaZA(cost);
            createPanel(tovar);
        }

    }

    public void createPanel(ArrayList<String> tovar) throws SQLException, ClassNotFoundException {


        for(int i = 0; i < tovar.size(); i++){
            VBox vBox = new VBox();
            File file = new File("src/"+tovar.get(i));
            String localUrl = file.toURI().toString();
            ImageView image = new ImageView(localUrl);

            image.setFitHeight(200);
            image.setFitWidth(200);
            vBox.getChildren().add(image);
            vBox.setStyle("-fx-border-style: solid;" + "-fx-border-width: 1;" + "-fx-border-color: #f39870");
            Label title = new Label();
            Label razmer = new Label();
            Label cost = new Label();
            ObservableList<String> redact = FXCollections.observableArrayList("Продается", "Подписывается договр", "Сдается в аренду", "Продано");
            ComboBox<String> redactComboBox = new ComboBox<String>(redact);
            redactComboBox.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
            title.setText(tovar.get(++i));
            title.setMaxWidth(150);
            title.setMinHeight(40);
            title.setAlignment(Pos.CENTER);
            title.setFont(new Font("Italic", 15));
            title.setTextFill(Color.web("#6B76F5"));
            razmer.setText("Площадь: "+tovar.get(++i));
            razmer.setMaxWidth(300);
            razmer.setMinHeight(40);
            cost.setText("Стоимость: "+tovar.get(++i));
            cost.setMaxWidth(300);
            cost.setMinHeight(40);
            cost.setFont(new Font("Italic", 12));
            cost.setTextFill(Color.web("#FC2323"));
            String statys = tovar.get(++i);
            redactComboBox.setValue(statys);
            String id = tovar.get(++i);
            redactComboBox.setOnAction(actionEvent -> {
                try {
                    db.getUpdate(id,redactComboBox.getValue());
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            });


            vBox.getChildren().add(title);
            vBox.getChildren().add(razmer);
            vBox.getChildren().add(cost);
            vBox.getChildren().add(redactComboBox);
            vBox.setAlignment(Pos.CENTER);
            gridPane.setHalignment(vBox, HPos.CENTER);
            gridPane.add(vBox, colum, root);
            if (count % 2 == 0){
                colum++;
                count++;
            }else{
                root++;
                colum--;
                count++;
            }

        }

    }

    public void onExit(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 866, 551);
        stage.getIcons().add(new Image("file:src/img/home.jpeg"));
        stage.setTitle("Главная!");
        stage.setScene(scene);
        stage.show();
        Stage stageNow = (Stage) exit.getScene().getWindow();
        stageNow.close();

    }
    //открытие окна для добавления объявления
    public void onNewTovar(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("newTovar.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 900, 551);
        stage.getIcons().add(new Image("file:src/img/home.jpeg"));
        stage.setTitle("Создание новго товара");
        stage.setScene(scene);
        stage.show();


    }

}
