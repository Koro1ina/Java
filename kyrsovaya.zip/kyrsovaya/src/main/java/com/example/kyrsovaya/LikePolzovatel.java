package com.example.kyrsovaya;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.io.File;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class LikePolzovatel implements Initializable {
    @FXML
    private GridPane gridPane;

    DB db = new DB();


    int colum = 0;
    int root = 0;
    int count = 0;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //очищение gridPane
        gridPane.getChildren().clear();

        gridPane.setHgap(10);
        gridPane.setVgap(10);


        ArrayList<String> tovar = null;
        String idPolzovatel = String.valueOf(Avtorization.idPolzovatel);
        try {
            tovar = db.getLikeGilya(idPolzovatel);
            System.out.println(tovar);
            createPanel(tovar);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }



    }

    //генерация объявления
    public void createPanel(ArrayList<String> tovar) throws SQLException, ClassNotFoundException {


        for(int i = 0; i < tovar.size(); i++){
            VBox vBox = new VBox();
            File file = new File("src/"+tovar.get(i));
            String localUrl = file.toURI().toString();
            ImageView image = new ImageView(localUrl);

            image.setFitHeight(200);
            image.setFitWidth(200);
            vBox.getChildren().add(image);
            vBox.setStyle("-fx-border-style: solid;" + "-fx-border-width: 1;" + "-fx-border-color: #f39870");
            Label title = new Label();
            Label razmer = new Label();
            Label cost = new Label();
            title.setText(tovar.get(++i));
            title.setMaxWidth(150);
            title.setMinHeight(40);
            title.setAlignment(Pos.CENTER);
            title.setFont(new Font("Italic", 15));
            title.setTextFill(Color.web("#040f2c"));
            razmer.setText("Площадь: "+tovar.get(++i));
            razmer.setMaxWidth(300);
            razmer.setMinHeight(40);
            cost.setText("Стоимость: "+tovar.get(++i));
            cost.setMaxWidth(300);
            cost.setMinHeight(40);
            cost.setFont(new Font("Italic", 20));
            cost.setTextFill(Color.web("#FC2323"));
            vBox.getChildren().add(title);
            vBox.getChildren().add(razmer);
            vBox.getChildren().add(cost);
            vBox.setAlignment(Pos.CENTER);
            gridPane.setHalignment(vBox, HPos.CENTER);
            gridPane.add(vBox, colum, root);
            if (count % 2 == 0){
                colum++;
                count++;
            }else{
                root++;
                colum--;
                count++;
            }

        }

    }

}
