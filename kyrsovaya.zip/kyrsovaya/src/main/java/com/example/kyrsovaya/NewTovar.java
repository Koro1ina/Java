package com.example.kyrsovaya;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.Stack;

public class NewTovar implements Initializable {

    @FXML
    public TextField name;

    @FXML
    public TextArea address;

    @FXML
    public TextField razmer;
    @FXML
    public TextField cost;
    @FXML
    public TextArea dop;
    @FXML
    public TextField prodavez;
    @FXML
    public TextField foto;
    @FXML
    public ComboBox type;
    @FXML
    public Button newObyvlenie ;

    DB db = new DB();
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //стили для элементов в окне
        name.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        address.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        razmer.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        cost.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        dop.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        prodavez.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        foto.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        type.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        newObyvlenie.setStyle("-fx-background-color: #f39870");


        ArrayList<String> tovarType= null;
        try {
            tovarType = db.getTovarType();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        type.getItems().addAll(tovarType);

    }

    //добавление нового объявления в бд
    public void onNewObyavleniy(ActionEvent actionEvent) throws SQLException, ClassNotFoundException, ParseException {
        //берем текущюю дату
        Date dateNow = new Date();
        //переделанную дату в определенный формат
        SimpleDateFormat formatForDateNow = new SimpleDateFormat("yyyy-MM-dd");
        String dataS = formatForDateNow.format(dateNow);
        Integer id = db.getId()+1;
        String nameText = name.getText();
        String addressText = address.getText();
        String razmerText = razmer.getText();
        String costText = cost.getText();
        String dopText = dop.getText();
        String prodavezText = prodavez.getText();
        String dataE = "";
        String typeText = (String) type.getValue();
        Integer statys = 1;
        Integer sotrydnic = Avtorization.id;
        String imgText = foto.getText();
        db.getInsert(id, nameText, addressText, razmerText, costText, dopText, prodavezText, dataS, dataE, typeText, statys, sotrydnic, imgText);
    }



}
