package com.example.kyrsovaya;


import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;


import java.awt.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Administrator implements Initializable {
    @FXML
    private GridPane gridPane;
    @FXML
    private ComboBox filter;
    @FXML
    private ComboBox sortirovca;
    @FXML
    private Button exit;
    @FXML
    private Button news;

    //подключение класса с бд
    DB db = new DB();

    //переменные для отображения объявления в GridPane
    int colum = 0;
    int root = 0;
    int count = 0;

    public static String id = String.valueOf(0);


    //при загрузки страницы будут отображаться объявления
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //у vbox будут границы
        sortirovca.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        filter.setStyle("-fx-border-style: solid;" + "-fx-border-width: 3;" + "-fx-border-color: #f39870");
        exit.setStyle("-fx-background-color: #f39870");
        news.setStyle("-fx-background-color: #f39870");
        gridPane.getChildren().clear();

        //расстояние между элементами GridPane
        gridPane.setHgap(10);
        gridPane.setVgap(10);


        //список получаемый при запросе к бд
        ArrayList<String> tovar = null;

        try {
            tovar = db.getGilyaPolzovatel();
            System.out.println(tovar);
            createPanel(tovar);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        //формировннии элементов фильтра и сортировки при загрузки страницы
        try {
            ArrayList<String> tovarType= db.getTovarType();
            tovarType.add("Все");
            filter.getItems().addAll(tovarType);
            sortirovca.getItems().addAll("Название от А-Я", "Название от Я-А", "По цене (от большей)", "По цене (от меньшей)");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

    // при выборе элемента в фильтре
    public void clickFilter1(ActionEvent event) throws SQLException, ClassNotFoundException {


        gridPane.getChildren().clear();

        gridPane.setHgap(10);
        gridPane.setVgap(10);

        colum = 0;
        root = 0;



        //получаем значение на которое было нажато
        String tovarType = (String) filter.getValue();

        if(tovarType.equals("Все")){
            ArrayList<String> tovar = db.getGilyaPolzovatel();
            createPanel(tovar);
        }else{
            ArrayList<String> tovar = db.getFilter(tovarType);
            createPanel(tovar);
        }





    }

    //то, что происходит при нажатии на элемент сортировки
    public void clickSortirovca1(ActionEvent event) throws SQLException, ClassNotFoundException {

        gridPane.getChildren().clear();


        gridPane.setHgap(20);
        gridPane.setVgap(20);

        String name = "name";
        String cost = "cost";

        colum = 0;
        root = 0;


        String tovarType = (String) sortirovca.getValue();




        if(tovarType.equals("Название от А-Я")){
            ArrayList<String> tovar = db.getSortirovcaAZ(name);
            createPanel(tovar);
        }else if (tovarType.equals("Название от Я-А")){
            ArrayList<String> tovar = db.getSortirovcaZA(name);
            createPanel(tovar);
        }else if (tovarType.equals("По цене (от большей)")){
            ArrayList<String> tovar = db.getSortirovcaZA(cost);
            createPanel(tovar);
        }else if (tovarType.equals("По цене (от меньшей)")){
            ArrayList<String> tovar = db.getSortirovcaZA(cost);
            createPanel(tovar);
        }

    }

    public void createPanel(ArrayList<String> tovar) throws SQLException, ClassNotFoundException {


        //загрузка объявлений
        for(int i = 0; i < tovar.size(); i++){
            VBox vBox = new VBox();
            HBox hBox = new HBox();
            //выбираем картику из папки img
            File file = new File("src/"+tovar.get(i));
            String localUrl = file.toURI().toString();
            ImageView image = new ImageView(localUrl);
            // задаем всем картинкам один размер
            image.setFitHeight(200);
            image.setFitWidth(200);
            //добавление картинки в VBox
            vBox.getChildren().add(image);
            vBox.setStyle("-fx-border-style: solid;" + "-fx-border-width: 1;" + "-fx-border-color: #f39870");
            Label title = new Label();
            Label razmer = new Label();
            Label cost = new Label();
            Button redact = new Button("Редактировать");
            Button delete = new Button("Удалить");
            redact.setStyle("-fx-background-color: #f39870");
            delete.setStyle("-fx-background-color: #f39870");
            //задаем стили для lable и button
            title.setText(tovar.get(++i));
            title.setMaxWidth(150);
            title.setMinHeight(40);
            title.setAlignment(Pos.CENTER);
            title.setFont(new Font("Italic", 15));
            title.setTextFill(Color.web("#040f2c"));
            razmer.setText("Площадь: "+tovar.get(++i));
            razmer.setMaxWidth(300);
            razmer.setMinHeight(40);
            cost.setText("Стоимость: "+tovar.get(++i));
            cost.setMaxWidth(300);
            cost.setMinHeight(40);
            cost.setFont(new Font("Italic", 20));
            cost.setTextFill(Color.web("#FC2323"));
            int idTovar = ++i;
            // при нажатии на кнопку "редактировать" открывается новое окно
            redact.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    Stage stage = new Stage();
                    //берется id объявления
                    id = tovar.get(idTovar);
                    FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("updateTovar.fxml"));
                    Scene scene = null;
                    try {
                        scene = new Scene(fxmlLoader.load(),494 , 194);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    stage.getIcons().add(new Image("file:src/img/home.jpeg"));
                    stage.setTitle("Редактирование");
                    stage.setScene(scene);
                    stage.show();

                }
            });
            //При нажатии на кнопку "удалить" удаляется объявление
            delete.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    try {
                        db.getDelete(tovar.get(idTovar));
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                    //обновление списка объявлений
                    gridPane.getChildren().clear();

                    gridPane.setHgap(10);
                    gridPane.setVgap(10);


                    ArrayList<String> tovar = null;

                    try {
                        tovar = db.getGilyaPolzovatel();
                        System.out.println(tovar);
                        createPanel(tovar);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            });
            //помещение в vBox всех элементов
            vBox.getChildren().add(title);
            vBox.getChildren().add(razmer);
            vBox.getChildren().add(cost);
            hBox.getChildren().add(redact);
            hBox.getChildren().add(delete);
            hBox.setAlignment(Pos.CENTER);
            hBox.setSpacing(30);
            vBox.getChildren().add(hBox);
            vBox.setAlignment(Pos.CENTER);
            vBox.setSpacing(10);
            //помещение vBox на gridPane
            gridPane.setHalignment(vBox, HPos.CENTER);
            gridPane.add(vBox, colum, root);
            //изменение значений колонки и столбца для gridPane
            if (count % 2 == 0){
                colum++;
                count++;
            }else{
                root++;
                colum--;
                count++;
            }

        }

    }

    //при нажатии на кнопку "выйти" переходит переход на главную страницу
    public void onExit(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 866, 551);
        stage.setTitle("Главная!");
        stage.setScene(scene);
        stage.show();
        Stage stageNow = (Stage) exit.getScene().getWindow();
        stageNow.close();

    }
    //при нажатии на кнопку формируется отчет
    public void onNewTovar(ActionEvent event) throws IOException, DocumentException, SQLException, ClassNotFoundException {
        //создаем документ
        Document document1 = new Document();
        //даем имя документу
        PdfWriter.getInstance(document1, new FileOutputStream("file.pdf"));
        //открываем документ
        document1.open();
        ArrayList<String> othet = db.getOthet();
        //подключаем стили для файла pdf
        com.itextpdf.text.Font font = FontFactory.getFont("src/DejaVuSans.ttf", "cp1251", BaseFont.EMBEDDED, 10);

        for (int i = 0; i < othet.size(); i++){
            //записываем в параграфы значения
            Paragraph paragraphOne = new Paragraph("Название: " + othet.get(i), font);
            Paragraph paragraphOne1 = new Paragraph("Адрес: " + othet.get(++i), font);
            Paragraph paragraphOne2= new Paragraph("Стоимость: " + othet.get(++i), font);
            Paragraph paragraphOne3 = new Paragraph("Дополнительная информация: " + othet.get(++i), font);
            Paragraph paragraphOne4 = new Paragraph("Имя продавца: " + othet.get(++i), font);
            Paragraph paragraphOne5 = new Paragraph("Дата создания объявления: " + othet.get(++i), font);
            Paragraph paragraphOne6 = new Paragraph("ФИО сотрудника: " + othet.get(++i), font);
            Paragraph paragraphOne7 = new Paragraph(" ");
            //добавляем параграфы в файл
            document1.add(paragraphOne);
            document1.add(paragraphOne1);
            document1.add(paragraphOne2);
            document1.add(paragraphOne3);
            document1.add(paragraphOne4);
            document1.add(paragraphOne5);
            document1.add(paragraphOne6);
            document1.add(paragraphOne7);
        }
        //закрываем файл
        document1.close();

        //открываем файл
        if (Desktop.isDesktopSupported()) {
            try {
                File myFile = new File( "file.pdf");
                Desktop.getDesktop().open(myFile);
            } catch (IOException ex) {
                // no application registered for PDFs
            }
        }
    }

}
